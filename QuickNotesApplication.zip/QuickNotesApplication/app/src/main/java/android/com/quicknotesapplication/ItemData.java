package android.com.quicknotesapplication;

public class ItemData {


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public byte[] getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(byte[] imageUrl) {
        this.imageUrl = imageUrl;
    }

    private String title;
    private byte[] imageUrl;

    public ItemData() {}

    public ItemData(String title,byte[] imageUrl){

        this.title = title;
        this.imageUrl = imageUrl;
    }
    // getters & setters
}
