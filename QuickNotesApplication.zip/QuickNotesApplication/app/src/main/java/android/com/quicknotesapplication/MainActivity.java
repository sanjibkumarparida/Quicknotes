package android.com.quicknotesapplication;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button voiceRecorder;
    Button capture;
    Button stopRecorder;

    private static final int CAMERA_REQUEST = 1888;
    ImageView mimageView;

    MediaRecorder recorder;
    File audiofile = null;
    static final String TAG = "MediaRecording";

    RecyclerView recyclerView;
    ItemData itemData = new ItemData();
    ArrayList<ItemData> itemsData = new ArrayList<ItemData>();

    byte[] byteArray;
    Database mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDatabase = new Database(this);

        voiceRecorder = (Button)findViewById(R.id.voicerecorder);
        stopRecorder = (Button)findViewById(R.id.stoprecorder);
        capture = (Button)findViewById(R.id.captureimage);

        recyclerView = (RecyclerView)findViewById(R.id.my_recycler_view);

        voiceRecorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Creating file
                File dir = Environment.getExternalStorageDirectory();
                try {
                    audiofile = File.createTempFile("sound", ".3gp", dir);
                } catch (IOException e) {
                    Log.e(TAG, "external storage access error");
                    return;
                }

                try {
                //Creating MediaRecorder and specifying audio source, output format, encoder & output format
                recorder = new MediaRecorder();
                recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                recorder.setOutputFile(audiofile.getAbsolutePath());

                    recorder.prepare();
                    recorder.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });

        stopRecorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //stopping recorder
                recorder.stop();
                recorder.release();
                //after stopping the recorder, create the sound file and add it to media library.
                addRecordingToMediaLibrary();
            }
        });

        capture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takeImageFromCamera(view);
            }
        });

        mDatabase.addData(itemData);

        // 2. set layoutManger
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        // 3. create an adapter
        MyAdapter mAdapter = new MyAdapter(itemsData);
        // 4. set adapter
        recyclerView.setAdapter(mAdapter);
        // 5. set item animator to DefaultAnimator
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }

    public void takeImageFromCamera(View view) {
        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, CAMERA_REQUEST);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            Bitmap mphoto = (Bitmap) data.getExtras().get("data");
           // mimageView.setImageBitmap(mphoto);

            // Initializing a new ByteArrayOutputStream
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            // Compress the bitmap to jpeg format and 50% image quality
            mphoto.compress(Bitmap.CompressFormat.PNG,50,stream);

            // Create a byte array from ByteArrayOutputStream
            byteArray = stream.toByteArray();

            itemData.setImageUrl(byteArray);
            itemsData.add(itemData);
        }
    }

    public static byte[] getPictureByteOfArray(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    public Bitmap getBitmapFromByteArray(byte[] byteArray) {
        Bitmap compressedBitmap;
        // Create a bitmap from the byte array
        compressedBitmap = BitmapFactory.decodeByteArray(byteArray,0,byteArray.length);

        return compressedBitmap;
    }

    protected void addRecordingToMediaLibrary() {
        //creating content values of size 4
        ContentValues values = new ContentValues(4);
        long current = System.currentTimeMillis();
        values.put(MediaStore.Audio.Media.TITLE, "audio" + audiofile.getName());
        values.put(MediaStore.Audio.Media.DATE_ADDED, (int) (current / 1000));
        values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/3gpp");
        values.put(MediaStore.Audio.Media.DATA, audiofile.getAbsolutePath());

        //creating content resolver and storing it in the external content uri
        ContentResolver contentResolver = getContentResolver();
        Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Uri newUri = contentResolver.insert(base, values);

        itemData.setTitle(audiofile.getName());
        itemsData.add(itemData);


        Toast.makeText(this, "Added File " + newUri, Toast.LENGTH_LONG).show();
    }
}


