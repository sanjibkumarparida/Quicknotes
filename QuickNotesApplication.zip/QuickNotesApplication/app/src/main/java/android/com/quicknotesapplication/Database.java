package android.com.quicknotesapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {
    // All Static variables
    // Database Name
    private static final String DB_NAME = "images";
    // Database Version
    private static final int DB_VERSION = 1;
    // Table name
    public static final String TABLE_NAME = "image";
    // Drop table query
    public static final String DROP_QUERY = "DROP TABLE IF EXISTS " + TABLE_NAME;
    // Select all query
    public static final String GET_IMAGE_QUERY = "SELECT * FROM " + TABLE_NAME;
    // image table column names
    public static final String PHOTO_URL = "photo_url";
    public static final String PHOTO = "photo";
    public static final String TITLE = "title";
    // Create table
    //
    public static final String CREATE_TABLE_QUERY = "CREATE TABLE " + TABLE_NAME + "" +
            "(" +
            PHOTO_URL + " TEXT PRIMARY KEY not null," +
            PHOTO + " blob not null," +
            TITLE + " TEXT not null)";
    public Database(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }
    // Creating tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_QUERY);
    }
    // Upgrading tables
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        // Drop older table if existed
        db.execSQL(DROP_QUERY);
        // Create tables again
        this.onCreate(db);
    }

    public void addData(ItemData dataModel){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(PHOTO_URL,dataModel.getImageUrl());
        values.put(TITLE,dataModel.getTitle());
        // Inserting row
        db.insert(TABLE_NAME,null,values);
        // Closing DataBase connection
        db.close();
    }
}
